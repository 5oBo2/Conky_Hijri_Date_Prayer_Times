Moon Phases: Rounded Fill v4
============================
This set uses the exact ROUND crescent silhouette from your uploaded 31.png
(reference weather-pack icon), filled white. The dashed rim marks only the
non-illuminated edge of the same lunar disc, not a larger outside circle.
Full Moon is a pure white disc with no dashed outline. New Moon is all dashed.

Eight transparent 160x160 PNGs. Same names as your current Conky set.

To install: back up your current assets/moon folder and extract the ZIP
into the folder containing Sun_Moon.lua, for example:

  cd ~/.config/conky/Conky_Sun_Weather_Complete
  cp -a assets/moon assets/moon.backup
  unzip -o ~/Downloads/Moon_Phases_Rounded_Fill_v4.zip -d .
  python3 restart_new.py

If your instance runs from ~/.config/conky directly, cd there instead.
If restart_new.py is missing, manually restart the Conky Sun/Moon instance.

This is a stylized eight-stage icon set. The rounded crescent shape is
matched to the supplied design, not a photometric 22% illumination silhouette.
No Lua or configuration changes required.
