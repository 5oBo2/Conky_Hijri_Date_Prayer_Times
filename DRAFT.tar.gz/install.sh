#!/usr/bin/env bash
# Copy the complete widget to ~/.config/conky and set up KDE/XDG Autostart.
set -euo pipefail
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST="${XDG_CONFIG_HOME:-$HOME/.config}/conky"
AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart"
make_autostart=1
run_wizard=1
reset_settings=0
for opt in "$@"; do
  case "$opt" in
    --no-autostart) make_autostart=0 ;;
    --no-configure) run_wizard=0 ;;
    --reset-settings) reset_settings=1 ;;
    --help|-h)
      printf 'Usage: bash install.sh [--no-autostart] [--no-configure] [--reset-settings]\n'; exit 0 ;;
    *) printf 'Unknown option: %s\n' "$opt" >&2; exit 2 ;;
  esac
done
if ! command -v python3 >/dev/null 2>&1; then
  printf 'Python 3 is required. Install it before proceeding.\n' >&2
  exit 1
fi
if [[ "$SOURCE" != "$DEST" ]]; then
  if [[ -e "$DEST/settings.ini" ]]; then
    backup="${DEST}-backup-$(date +%Y%m%d-%H%M%S)"
    cp -a "$DEST" "$backup"
    printf 'Existing Conky directory backed up to: %s\n' "$backup"
  fi
  mkdir -p "$DEST"
  for filename in \
    Prayer_Times.lua Hijri_Date.lua Prayer_Data.lua Surface.lua \
    Hover_State.lua Settings.lua prayer_fetch.py conky_prayer_times.conf \
    conky_date.conf configure.py layout.py settings.ini start.sh \
    doctor.py README.md HOVER_ZONE.md install.sh; do
    if [[ "$filename" == settings.ini && -f "$DEST/settings.ini" && "$reset_settings" == 0 ]]; then
      printf 'Keeping your existing settings.ini (use --reset-settings to replace it).\n'
      continue
    fi
    cp -- "$SOURCE/$filename" "$DEST/$filename"
  done
  # A user-provided Athan recording placed beside install.sh travels with the install.
  if [[ -f "$SOURCE/athan.wav" ]]; then
    cp -- "$SOURCE/athan.wav" "$DEST/athan.wav"
  fi
fi
chmod +x "$DEST/start.sh" "$DEST/install.sh" "$DEST/configure.py" "$DEST/doctor.py" "$DEST/prayer_fetch.py"
if [[ "$make_autostart" == 1 ]]; then
  mkdir -p "$AUTOSTART"
  # XDG Desktop Entry Exec syntax requires double quotes around paths with spaces.
  escaped_dest="${DEST//\\/\\\\}"
  escaped_dest="${escaped_dest//\"/\\\"}"
  cat > "$AUTOSTART/conky-prayer-clock.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Prayer Times and Hijri Clock
Comment=Start the two Conky desktop widgets
Exec=/bin/bash "$escaped_dest/start.sh" --delay 5
TryExec=conky
Terminal=false
X-GNOME-Autostart-enabled=true
DESKTOP
  printf 'KDE/XDG Autostart entry installed at: %s\n' "$AUTOSTART/conky-prayer-clock.desktop"
fi
printf 'Installed to: %s\n' "$DEST"
printf 'Athan sound: copy your recording to %s/athan.wav\n' "$DEST"
if [[ "$run_wizard" == 1 && -t 0 ]]; then
  printf '\nSet location, size, and screen positions now? [Y/n] '
  read -r answer || answer='n'
  if [[ ! "$answer" =~ ^[nN] ]]; then
    python3 "$DEST/configure.py"
  fi
fi
printf '\nCheck your setup: python3 "%s/doctor.py"\n' "$DEST"
printf 'Start now: bash "%s/start.sh"\n' "$DEST"
if [[ "$make_autostart" == 1 ]]; then
  printf 'Autostart will activate on your next desktop login.\n'
fi
