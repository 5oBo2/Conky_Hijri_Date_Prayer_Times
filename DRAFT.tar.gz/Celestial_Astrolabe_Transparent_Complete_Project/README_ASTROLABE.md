# Celestial Astrolabe — alternative Moon/Sun Conky widget

A new, separately launchable version of `Sun_Moon.lua` based on **Concept A · Celestial Astrolabe** in the supplied HTML. The original widget remains **untouched**.

## Appearance

- **Fully transparent:** no dark panel, glass fill, border, or surrounding drop shadow; artwork floats over your wallpaper
- 48 watch-dial ticks, solar-noon apex, glow and sunrise-to-sunset amber/pink arc
- Nighttime blue arc and moving progress indicator
- Continuously drawn waxing/waning moon with earthshine, maria and craters
- Sunrise, sunset, daylight/tonight lengths, day/night progress and 24-hour gradient timeline
- Same configured `ITC Avant Garde Pro XLt` font, via `[appearance] font` in `settings.ini`

## Transparent variant

This replaces **only the appearance of the alternative Astrolabe**. The original Sun/Moon widget and its configuration are unaffected. The Conky window is ARGB-transparent (`own_window_argb_visual = true`, `own_window_argb_value = 0`, `own_window_transparent = true`), and the Lua drawing function does not paint a background rectangle/card or shadow. The solar glow and moon halo are still part of the artwork, not a surrounding panel.

If you already have the Astrolabe running, restart that **specific Conky process** to reload the new Lua file. Running `start_astrolabe.sh` while the old Astrolabe is still open may create a duplicate widget.

## Test this alternate version

With a complete extracted archive, open a terminal in the extracted folder and run:

```bash
bash start_astrolabe.sh
```

Or run directly without detaching:

```bash
conky -c conky_sun_moon_astrolabe.conf
```

**To add it to your already installed widgets** in `~/.config/conky/`, copy only these three files there (the rest of the original app is already installed):

- `Sun_Moon_Astrolabe.lua`
- `conky_sun_moon_astrolabe.conf`
- `start_astrolabe.sh` (optional convenience launcher)

Then run:

```bash
bash ~/.config/conky/start_astrolabe.sh
```

There is **no need to change** `Sun_Moon.lua`, `settings.ini`, `start.sh` or your prayer/weather widgets. Data is read from the same `Weather_Data.lua` and `Prayer_Data.lua` components. If sunrise/sunset data has not yet loaded, the lunar phase remains visible, and the solar readouts show a loading state.

## Font and positioning

The new file reads `font = ITC Avant Garde Pro XLt` straight from your existing `[appearance]` settings. The font must be installed on your system, as in the original project. No font file is bundled.

It also reuses `sun_moon_scale`. The 416 × 432 logical pixel transparent drawing area defaults to a position **455 × `sun_moon_scale` pixels right** of the original Moon widget, so both can be viewed together for comparison. To position it independently, add these keys under `[placement]` in your existing `settings.ini`:

```ini
sun_moon_astrolabe_x = 950
sun_moon_astrolabe_y = 40
```

These are example coordinates. Remove them to restore the side-by-side default. Restart the Astrolabe Conky process after changing settings.

## Accuracy and limitations

- The central moon represents current *phase*, not where the Moon appears in the sky. Its phase and illumination use the same approximate local algorithm as the original, but the terminator is drawn continuously rather than selecting one of eight PNGs.
- The upper dot is elapsed sunrise-to-sunset progress. The lower blue dot is elapsed nighttime progress, **not** lunar position.
- `Solar Noon` is the midpoint between the sunrise and sunset values used by the original widget, not true apparent solar noon from a separate astronomical ephemeris.
- As with the original, when local prayer data is available the sunrise and Maghrib times take precedence over weather API values. The machine's timezone should correspond to the selected location.
- The colored horizontal bar maps sunrise, sunset and current time into local **clock hours** across 00:00–24:00, while `TONIGHT` is sunset until tomorrow's sunrise.
- This Conky/Cairo design is built as runnable source but cannot be displayed on the author's Linux desktop here; inspect the widget on your actual KDE/Conky installation for final pixel-perfect comparison.
