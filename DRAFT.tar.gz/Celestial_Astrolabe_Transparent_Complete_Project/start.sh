#!/usr/bin/env bash
# Normal launch: all 4. Test only the two NEW widgets with --new-only.
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
selection=all
if [[ "${1:-}" == '--new-only' ]]; then
  selection=new; shift
elif [[ "${1:-}" == '--existing-only' ]]; then
  selection=existing; shift
fi
if [[ "${1:-}" == '--delay' ]]; then
  seconds="${2:-5}"
  [[ "$seconds" =~ ^[0-9]+$ ]] || { echo 'Delay must be a nonnegative integer.' >&2; exit 2; }
  sleep "$seconds"
  shift 2
fi
if [[ $# -ne 0 ]]; then
  echo 'Usage: start.sh [--new-only|--existing-only] [--delay SECONDS]' >&2
  exit 2
fi
if ! command -v conky >/dev/null 2>&1; then
  echo 'Conky is missing. Install Conky with Lua/Cairo support.' >&2
  exit 1
fi
if [[ "$selection" != new ]]; then
  conky -d -c "$DIR/conky_date.conf"
  conky -d -c "$DIR/conky_prayer_times.conf"
fi
if [[ "$selection" != existing ]]; then
  conky -d -c "$DIR/conky_weather.conf"
  conky -d -c "$DIR/conky_sun_moon.conf"
fi
