#!/usr/bin/env python3
"""Restart only THIS directory's two new Conky windows on Linux.

Does not touch prayer/date windows or unrelated Conky instances.
Use --stop-only or --list to inspect/stop without launching.
"""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TARGETS = {(ROOT / 'conky_weather.conf').resolve(),
           (ROOT / 'conky_sun_moon.conf').resolve()}


def matching_pids():
    matches = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            argv = [os.fsdecode(a) for a in (entry / 'cmdline').read_bytes().split(b'\0') if a]
            if not argv or Path(argv[0]).name != 'conky':
                continue
            for i, arg in enumerate(argv[1:], 1):
                candidate = None
                if arg in ('-c', '--config') and i + 1 < len(argv):
                    candidate = argv[i+1]
                elif arg.startswith('--config='):
                    candidate = arg.partition('=')[2]
                if candidate and Path(candidate).expanduser().resolve() in TARGETS:
                    matches.append(int(entry.name))
                    break
        except (OSError, ValueError, PermissionError):
            pass
    return sorted(matches)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list', action='store_true', help='show matching widget PIDs only')
    parser.add_argument('--stop-only', action='store_true', help='stop matching widgets without restarting')
    args = parser.parse_args()
    current = matching_pids()
    print('New widget PIDs:', ', '.join(map(str, current)) or '(none)')
    if args.list:
        return 0
    for pid in current:
        try:
            os.kill(pid, signal.SIGTERM)
            print('Stopped:', pid)
        except ProcessLookupError:
            pass
        except PermissionError as exc:
            print(f'Cannot stop {pid}: {exc}', file=sys.stderr)
            return 1
    if current:
        for _ in range(35):
            if not any(pid in matching_pids() for pid in current):
                break
            time.sleep(.1)
        else:
            print('Previous widget instance still running; cannot safely restart.', file=sys.stderr)
            return 1
    if args.stop_only:
        return 0
    return subprocess.run(['bash', str(ROOT / 'start.sh'), '--new-only'], check=False).returncode


if __name__ == '__main__':
    sys.exit(main())
