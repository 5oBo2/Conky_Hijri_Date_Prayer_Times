-- Full circular, time-aware Sun/Night clock. Moon phase stays fixed in the centre.
-- Note: moving NIGHT dot is elapsed-night progress, not the Moon's sky position.
require('cairo')
local base = debug.getinfo(1, 'S').source:match('^@(.*/)') or './'
local Surface = dofile(base .. 'Surface.lua')
local Weather = dofile(base .. 'Weather_Data.lua')
local Prayer = dofile(base .. 'Prayer_Data.lua')
local settings = dofile(base .. 'Settings.lua')
local SCALE = settings.scale('sun_moon')
local FONT = settings.get('appearance', 'font', 'DejaVu Sans')
local PI = math.pi
local CX, CY, R = 174, 140, 107
local WHITE = {0.94, 0.97, 1, 0.91}
local MUTED = {0.71, 0.82, 0.88, 0.83}
local GOLD = {1.0, 0.78, 0.37, 1.0}
local BLUE = {0.54, 0.83, 1, 1}
local moon_icons = {}
local last_prayer_ensure = 0

local function rgba(cr, c, a)
    cairo_set_source_rgba(cr, c[1], c[2], c[3], a or c[4])
end
local function text_at(cr, s, x, y, size, c, centered)
    cairo_set_font_size(cr, size)
    rgba(cr, c or WHITE)
    if centered then
        local ext = cairo_text_extents_t:create()
        cairo_text_extents(cr, tostring(s), ext)
        x = x - ext.x_advance / 2
    end
    cairo_move_to(cr, x, y)
    cairo_show_text(cr, tostring(s))
end
local function point(angle)
    return CX + R * math.cos(angle), CY + R * math.sin(angle)
end
local function dot(cr, x, y, r, c, alpha)
    rgba(cr, c, alpha)
    cairo_arc(cr, x, y, r, 0, 2*PI)
    cairo_fill(cr)
end
local function clamp(v)
    return math.max(0, math.min(1, v))
end

-- Approximate illuminated phase from geocentric Moon/Sun ecliptic longitudes.
-- Correct phase orientation; no internet connection or Python modules required.
local function moon_phase(now)
    local jd = now / 86400 + 2440587.5
    local t = (jd - 2451545.0) / 36525
    local function sine(deg) return math.sin(deg * PI / 180) end
    local sun_m = 357.5291092 + 35999.0502909*t
    local sun_l = 280.46646 + 36000.76983*t + (1.914602-0.004817*t)*sine(sun_m)
                     + 0.019993*sine(2*sun_m)
    local moon_m = 134.9633964 + 477198.8675055*t
    local d = 297.8501921 + 445267.1114034*t
    local moon_l = 218.3164477 + 481267.88123421*t
        + 6.289*sine(moon_m) + 1.274*sine(2*d-moon_m)
        + 0.658*sine(2*d) + 0.214*sine(2*moon_m)
        - 0.186*sine(sun_m) - 0.059*sine(2*d-2*moon_m)
        - 0.057*sine(2*d-sun_m-moon_m)
    local separation = (moon_l - sun_l) % 360
    local illum = (1-math.cos(separation * PI/180))/2
    local phases = {
        {'new', 'New Moon'},
        {'waxing_crescent', 'Waxing Crescent'},
        {'first_quarter', 'First Quarter'},
        {'waxing_gibbous', 'Waxing Gibbous'},
        {'full', 'Full Moon'},
        {'waning_gibbous', 'Waning Gibbous'},
        {'last_quarter', 'Last Quarter'},
        {'waning_crescent', 'Waning Crescent'},
    }
    local index = math.floor(((separation+22.5)%360)/45)+1
    return phases[index][1], phases[index][2], math.floor(illum*100+0.5)
end

local function moon_icon(cr, id, size, day)
    if not moon_icons[id] then
        moon_icons[id] = cairo_image_surface_create_from_png(base .. 'assets/moon/' .. id .. '.png')
    end
    local surface = moon_icons[id]
    if not surface then return end
    cairo_save(cr)
    cairo_translate(cr, CX-size/2, CY-size/2)
    cairo_scale(cr, size/160, size/160)
    cairo_set_source_surface(cr, surface, 0, 0)
    cairo_paint_with_alpha(cr, day and 0.82 or 1)
    cairo_restore(cr)
end

local function sun_schedule(now, weather)
    local events = {}
    if weather then
        events = {
            sunrise=weather.sunrise, sunset=weather.sunset,
            yesterday_sunset=weather.yesterday_sunset,
            tomorrow_sunrise=weather.tomorrow_sunrise,
            sunrise_label=weather.sunrise_label,
            sunset_label=weather.sunset_label,
        }
    end
    -- Prefer existing prayer widget's Sunrise and Maghrib if the displayed
    -- location shares the computer's local timezone (the original requirement).
    -- Also works with just the prayer cache if weather is temporarily offline.
    if not weather or os.date('%Y-%m-%d', now) == weather.local_date then
        local today = os.date('%Y-%m-%d', now)
        local yesterday = Prayer.date_plus(today, -1)
        local tomorrow = Prayer.date_plus(today, 1)
        if now - last_prayer_ensure > 60 then
            Prayer.ensure_dates({today, yesterday, tomorrow}, now)
            last_prayer_ensure = now
        end
        local d0, d1, d2 = Prayer.get(yesterday), Prayer.get(today), Prayer.get(tomorrow)
        if d0 then
            events.yesterday_sunset = Prayer.timestamp(yesterday, d0.timings.Maghrib)
                or events.yesterday_sunset
        end
        if d1 then
            events.sunrise = Prayer.timestamp(today, d1.timings.Sunrise) or events.sunrise
            events.sunset = Prayer.timestamp(today, d1.timings.Maghrib) or events.sunset
            events.sunrise_label = d1.timings.Sunrise
            events.sunset_label = d1.timings.Maghrib
        end
        if d2 then
            events.tomorrow_sunrise = Prayer.timestamp(tomorrow, d2.timings.Sunrise)
                or events.tomorrow_sunrise
        end
    end
    for _, key in ipairs({'yesterday_sunset', 'sunrise', 'sunset', 'tomorrow_sunrise',
                          'sunrise_label', 'sunset_label'}) do
        if not events[key] then return nil end
    end
    if not (events.yesterday_sunset < events.sunrise and events.sunrise < events.sunset
            and events.sunset < events.tomorrow_sunrise) then return nil end
    local day = now >= events.sunrise and now < events.sunset
    local p
    if day then
        p = clamp((now-events.sunrise)/(events.sunset-events.sunrise))
    elseif now < events.sunrise then
        p = clamp((now-events.yesterday_sunset)/(events.sunrise-events.yesterday_sunset))
    else
        p = clamp((now-events.sunset)/(events.tomorrow_sunrise-events.sunset))
    end
    return {day=day, fraction=p, sunrise=events.sunrise_label:sub(1,5),
            sunset=events.sunset_label:sub(1,5),
            daylight_seconds=events.sunset-events.sunrise,
            tonight_seconds=events.tomorrow_sunrise-events.sunset}
end

local function draw_arcs(cr, day, frac)
    for i=0,48 do
        local f=i/48
        local a=PI+PI*f
        local x,y=point(a)
        local active=day and f<=frac
        dot(cr,x,y,active and 2.2 or 1.65,GOLD,
            day and (active and .95 or .37) or .23)
    end
    for i=0,48 do
        local f=i/48
        local a=PI*f
        local x,y=point(a)
        local active=(not day) and f<=frac
        dot(cr,x,y,active and 2.2 or 1.65,BLUE,
            not day and (active and .93 or .37) or .23)
    end
end

local function duration(seconds)
    local minutes = math.floor(math.max(0, seconds) / 60 + .5)
    return string.format('%dh %02dm', math.floor(minutes/60), minutes%60)
end

local function duration_bar(cr, day, night)
    local total = day + night
    if total <= 0 then return end
    local left, right, y = 25, 323, 314
    local split = left + (right-left) * day / total
    cairo_set_line_width(cr, 5.5)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)
    rgba(cr, GOLD, 0.94)
    cairo_move_to(cr, left, y)
    cairo_line_to(cr, split, y)
    cairo_stroke(cr)
    rgba(cr, BLUE, 0.78)
    cairo_move_to(cr, split+2, y)
    cairo_line_to(cr, right, y)
    cairo_stroke(cr)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_BUTT)
end

function conky_main()
    if not conky_window then return end
    local now = os.time()
    local weather = Weather.get(now)
    local schedule = sun_schedule(now, weather)
    local phase_id, phase_name, illumination = moon_phase(now)
    local is_day = schedule and schedule.day
    local surface, owned = Surface.acquire()
    if not surface then return end
    local cr = cairo_create(surface)
    cairo_scale(cr, SCALE, SCALE)
    cairo_select_font_face(cr, FONT, CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)

    -- The arc is a clock: moving SUN above, night-progress DOT below.
    draw_arcs(cr, is_day or false, schedule and schedule.fraction or 0)

    -- The fixed moon phase is an outline with an empty interior. Split the
    -- horizon behind it so it cannot show through the transparent moon icon.
    rgba(cr, WHITE, .62)
    cairo_set_line_width(cr, 1.5)
    cairo_move_to(cr, CX-R, CY)
    cairo_line_to(cr, CX-44, CY)
    cairo_move_to(cr, CX+44, CY)
    cairo_line_to(cr, CX+R, CY)
    cairo_stroke(cr)
    dot(cr, CX-R, CY, 3.2, WHITE, .93)
    dot(cr, CX+R, CY, 3.2, WHITE, .93)

    if schedule then
        local angle = schedule.day and (PI + PI*schedule.fraction) or (PI*schedule.fraction)
        local x,y = point(angle)
        if schedule.day then
            dot(cr, x,y,19,GOLD,.09)
            dot(cr, x,y,13,GOLD,.18)
            dot(cr, x,y,9,GOLD,.97)
            dot(cr, x,y,3,WHITE,.74)
        else
            dot(cr, x,y,15,BLUE,.10)
            dot(cr, x,y,10,BLUE,.23)
            dot(cr, x,y,5.5,BLUE,1)
            dot(cr, x,y,2,WHITE,1)
        end
        -- Times go OUTSIDE the orbit, never on top of the horizon or arc dots.
        text_at(cr,schedule.sunrise,35,CY+4,13,WHITE,true)
        text_at(cr,schedule.sunset,313,CY+4,13,WHITE,true)
    else
        text_at(cr,'--:--',35,CY+4,13,MUTED,true)
        text_at(cr,'--:--',313,CY+4,13,MUTED,true)
    end
    text_at(cr,'Sunrise',35,CY+21,10,MUTED,true)
    text_at(cr,'Sunset',313,CY+21,10,MUTED,true)

    -- The center is intentionally STATIC: actual lunar phase, not sky position.
    moon_icon(cr,phase_id,85,not not is_day)
    text_at(cr,phase_name,CX,206,15,WHITE,true)
    text_at(cr,string.format('%d%% illuminated',illumination),CX,226,12,MUTED,true)

    -- Separate, measurable durations + proportion of daylight/tonight.
    if schedule then
        text_at(cr,'DAYLIGHT',25,274,12,GOLD)
        text_at(cr,duration(schedule.daylight_seconds),25,297,19,WHITE)
        text_at(cr,'TONIGHT',215,274,12,BLUE)
        text_at(cr,duration(schedule.tonight_seconds),215,297,19,WHITE)
        duration_bar(cr, schedule.daylight_seconds, schedule.tonight_seconds)
    else
        text_at(cr,'Waiting for sunrise / sunset data…',CX,288,12,MUTED,true)
    end
    cairo_destroy(cr)
    Surface.release(surface,owned)
end
