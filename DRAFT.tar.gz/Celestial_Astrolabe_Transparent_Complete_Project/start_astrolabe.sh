#!/usr/bin/env bash
# Launch only the alternative Astrolabe widget (does not stop the original).
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v conky >/dev/null 2>&1; then
  echo 'Conky is required, including Lua/Cairo support.' >&2
  exit 1
fi
conky -d -c "$DIR/conky_sun_moon_astrolabe.conf"
