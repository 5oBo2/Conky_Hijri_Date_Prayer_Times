## Visual refinement: outlined Moon + daylight/night durations (v2)

The weather icon was moved **23px left and 20px up** relative to v1 (actual
visible bounds depend on the WeatherDesk artwork). Fine-tune it in `settings.ini`:

```ini
[appearance]
weather_icon_x = 174
weather_icon_y = -13
weather_icon_size = 137
```

The Sun/Moon orbit keeps a horizontal horizon for clarity. The fixed central
moon phase uses transparent **white-outline artwork**: the user-provided
WeatherDesk crescent (31.png) is used for both waxing/waning crescents; quarter,
gibbous and full/new phases are redrawn to match its round-ended strokes.
The horizon is split behind the center so it does not shine through the icon.
Sunrise/sunset times are **outside** the arc, just beyond the horizon endpoints,
with labels underneath. There are now two additional readouts **below the orbit**:
`DAYLIGHT` (today sunrise → today sunset), and `TONIGHT` (today sunset →
tomorrow sunrise). The bottom gold/blue bar is proportional to those actual
durations. Unlike a V-shaped horizon, its meaning remains unambiguous all year.

Two new Conky `.conf` files specify a font explicitly to suppress the fallback
`6x10` bitmap font warning on systems where that font is not installed.

**Update your existing extracted folder:** After backing it up, copy the
replacement `Weather.lua`, `Sun_Moon.lua`, `conky_weather.conf`,
`conky_sun_moon.conf`, `assets/moon/` PNGs, and settings if desired from this
release. Your location and widget positions do not need to change. Conky needs
to be restarted for the new drawing code and window height to take effect.

---

## Weather fetch timezone fix (17 November 2026)

This release fixes `Forecast date mismatch (local weather day changed); retry`
from the earlier `weather_fetch.py`. Open-Meteo's daily Unix timestamps
represent local-midnight instants; the old code converted them to UTC dates.
The fetcher now converts timestamps to the **forecast location's timezone**
and picks today's day by date, not a fixed index. The sunrise/sunset Unix
timestamps are kept as absolute instants for the circular animation.

If you already installed the earlier package, only replace
`~/.config/conky/weather_fetch.py`, then run:

```bash
python3 ~/.config/conky/weather_fetch.py --force
```

If you are testing the extracted ZIP, replace `weather_fetch.py` inside the
extracted folder and run `python3 weather_fetch.py --force` there. You do not
need to restart a running Conky instance once the cache is updated; the new
widgets reload cached data automatically. For a new launch use:

```bash
bash start.sh --new-only
```

---

# New Conky weather + Sun/Moon widgets

These additions **do not modify** `Prayer_Times.lua`, `Hijri_Date.lua`, their
`.conf` files, or existing Athan logic. All four widgets can start independently.

## Test the two new widgets without installing

1. Extract `Conky_Sun_Weather_Complete.zip` to a convenient folder on your Linux
   desktop (e.g. `~/Downloads/Conky_Sun_Weather_Complete`).
2. In that folder, check the pre-filled `[location]` coordinates and the `[placement]`
   values in `settings.ini` (defaults: Cairo; weather `40,40`, circle `420,40`).
   Use **your computer's local timezone** for the selected prayer location, as with
   the original prayer widget.
3. In a terminal inside the extracted directory:

   ```bash
   python3 configure.py --check
   python3 weather_fetch.py --force
   bash start.sh --new-only
   ```

   The `weather_fetch.py` command prints the first network error explicitly, if
   any. A connection is required initially; after that, cached data is reused.
   The circle can also use existing prayer-cache data for sunrise/sunset.
4. To change locations and sizing of only the two additions:

   ```bash
   python3 configure.py --widget new
   # or edit: weather_x, weather_y, sun_moon_x, sun_moon_y,
   #           weather_scale, sun_moon_scale directly in settings.ini.
   # To place them by monitor and corner:
   python3 configure.py --layout --widget new
   python3 configure.py --check-layout --widget new
   ```

   After editing settings, terminate the TEST Conky instances and re-launch.
   Do not blindly run `killall conky` if you have other Conky widgets running.

## Start each widget separately (debugging)

```bash
conky -c "$(pwd)/conky_weather.conf"
# in another terminal:
conky -c "$(pwd)/conky_sun_moon.conf"
```

Running without `-d` keeps the Conky output visible in the terminal for errors;
press Ctrl+C to stop that foreground instance. To run both in the background,
use `bash start.sh --new-only`.

## Install alongside your existing prayer/date widgets

```bash
bash install.sh
# or, to avoid new autostart changes while testing:
bash install.sh --no-autostart --no-configure
```

`install.sh` backs up an existing `~/.config/conky/` directory, preserves its
`settings.ini` by default, adds any missing new options without resetting your
values, and copies the weather/moon images. For the normal four-widget setup:

```bash
bash ~/.config/conky/start.sh
```

After installation, use the **installed** copy of `settings.ini`. Set the new
widget coordinates to fit your monitor(s), then restart those Conky instances.
`start.sh --existing-only` starts just the original prayer and date instances.

If you already have the original widgets running, **do not run** the full
four-widget launcher again without stopping the existing instances, or you
will get duplicates. For a safe first test, use `--new-only`.

## Appearance and data

- The weather widget shows the current temperature, **today's forecast high and
  low**, and current relative humidity, with the white WeatherDesk icon artwork
  provided in your original Rainmeter archive.
- Open-Meteo supplies current weather and forecast sun events (no API key for
  personal/non-commercial use, subject to their usage terms). Default refresh is
  every 20 minutes. One background Python process fills a shared, atomic cache.
- The circle uses eight transparent, white outline lunar phases. The crescents
  are based on your supplied WeatherDesk crescent. New moon is a dotted ring.
  Moon phase and illumination are computed locally from approximate solar/lunar
  geocentric longitudes and do not rely on the weather API.
- Sun travels along the upper dotted semicircle during daylight. A **small blue
  dot** travels along the bottom semicircle at night: this is an **elapsed-time
  indicator, not actual Moon altitude, moonrise, or moonset**. The moon-phase
  icon remains still in the center.
- Sunrise and Maghrib are used from the shared prayer cache whenever it is
  available and your PC timezone matches the configured location; otherwise
  Open-Meteo's sunrise/sunset timestamps are used.
- While weather is unavailable, the weather widget shows a fetching placeholder.
  The center moon phase renders even offline. The circle waits for a valid
  sunrise/sunset schedule from weather or the prayer cache to animate the dot.

### Files added

`Weather.lua`, `Sun_Moon.lua`, `Weather_Data.lua`, `weather_fetch.py`,
`conky_weather.conf`, `conky_sun_moon.conf`, `upgrade_settings.py`,
`assets/weather/*.png`, and `assets/moon/*.png`.

### Diagnostics

```bash
python3 doctor.py
python3 doctor.py --weather-fetch
# The log shows background refresh errors:
tail -n 40 ~/.cache/conky-sun-weather/fetch.log
```

If an icon isn't visible, verify `assets/weather/` or `assets/moon/` stayed
beside the `.lua` files. Ensure `conky --version` lists Lua/Cairo support.
See the existing README for the original widgets' instructions.
