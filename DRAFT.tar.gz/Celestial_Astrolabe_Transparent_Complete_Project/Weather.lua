-- Compact transparent WeatherDesk-inspired weather widget.
require('cairo')
local base = debug.getinfo(1, 'S').source:match('^@(.*/)') or './'
local Surface = dofile(base .. 'Surface.lua')
local Weather = dofile(base .. 'Weather_Data.lua')
local settings = dofile(base .. 'Settings.lua')
local SCALE = settings.scale('weather')
local FONT = settings.get('appearance', 'font', 'DejaVu Sans')
local WHITE = {1, 1, 1, 0.96}
local MUTED = {0.73, 0.81, 0.85, 0.88}
local BLUE = {0.10, 0.80, 1.0, 1}
local ORANGE = {1, 0.47, 0.19, 1}
local icons = {}
-- Tunable icon placement (widget-local units, before weather_scale).
local ICON_X = settings.number('appearance', 'weather_icon_x', 174)
local ICON_Y = settings.number('appearance', 'weather_icon_y', -13)
local ICON_SIZE = settings.number('appearance', 'weather_icon_size', 137)

local function color(cr, c)
    cairo_set_source_rgba(cr, c[1], c[2], c[3], c[4])
end
local function txt(cr, s, x, y, size, c)
    cairo_set_font_size(cr, size)
    color(cr, c or WHITE)
    cairo_move_to(cr, x, y)
    cairo_show_text(cr, tostring(s))
end
local function icon_code(wmo, day)
    -- Map Open-Meteo WMO weather codes to the original WeatherDesk icon set.
    if wmo == 0 then return day and 32 or 31 end
    if wmo == 1 then return day and 34 or 33 end
    if wmo == 2 then return day and 30 or 29 end
    if wmo == 3 then return 26 end
    if wmo == 45 or wmo == 48 then return 20 end
    if wmo >= 51 and wmo <= 57 then return 9 end
    if wmo >= 61 and wmo <= 65 then return 11 end
    if wmo == 66 or wmo == 67 then return 9 end
    if wmo >= 71 and wmo <= 77 then return 13 end
    if wmo >= 80 and wmo <= 82 then return 39 end
    if wmo == 85 or wmo == 86 then return 42 end
    if wmo >= 95 then return 0 end
    return 26
end
local function icon(cr, id, x, y, size)
    if not icons[id] then
        local path = base .. 'assets/weather/' .. id .. '.png'
        icons[id] = cairo_image_surface_create_from_png(path)
    end
    local surface = icons[id]
    if not surface then return end
    cairo_save(cr)
    cairo_translate(cr, x, y)
    cairo_scale(cr, size / 256, size / 256)
    cairo_set_source_surface(cr, surface, 0, 0)
    cairo_paint(cr)
    cairo_restore(cr)
end
local function up_arrow(cr, x, y)
    color(cr, ORANGE); cairo_set_line_width(cr, 1.6)
    cairo_move_to(cr, x, y + 7); cairo_line_to(cr, x, y - 5)
    cairo_move_to(cr, x-3, y-2); cairo_line_to(cr, x, y-5); cairo_line_to(cr, x+3, y-2)
    cairo_stroke(cr)
end
local function down_arrow(cr, x, y)
    color(cr, MUTED); cairo_set_line_width(cr, 1.6)
    cairo_move_to(cr, x, y - 5); cairo_line_to(cr, x, y + 7)
    cairo_move_to(cr, x-3, y+4); cairo_line_to(cr, x, y+7); cairo_line_to(cr, x+3, y+4)
    cairo_stroke(cr)
end
local function droplet(cr, x, y)
    color(cr, BLUE); cairo_set_line_width(cr, 2)
    cairo_move_to(cr, x, y - 10)
    cairo_curve_to(cr, x-5, y-2, x-7, y+1, x-5, y+5)
    cairo_curve_to(cr, x-2, y+10, x+3, y+9, x+5, y+5)
    cairo_curve_to(cr, x+7, y+1, x+5, y-2, x, y-10)
    cairo_close_path(cr); cairo_stroke(cr)
end

function conky_main()
    if not conky_window then return end
    local weather = Weather.get(os.time())
    local surface, owned = Surface.acquire()
    if not surface then return end
    local cr = cairo_create(surface)
    cairo_scale(cr, SCALE, SCALE)
    cairo_select_font_face(cr, FONT, CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL)
    if not weather then
        txt(cr, 'Weather', 24, 68, 39)
        txt(cr, 'Fetching current conditions…', 26, 113, 16, MUTED)
    else
        local temp = string.format('%d°', weather.temperature)
        txt(cr, temp, 24, 83, 70)
        up_arrow(cr, 36, 108)
        txt(cr, string.format('%d°', weather.high), 47, 115, 19)
        down_arrow(cr, 121, 108)
        txt(cr, string.format('%d°', weather.low), 133, 115, 19, MUTED)
        droplet(cr, 36, 142)
        txt(cr, string.format('%d%%', weather.humidity), 49, 148, 19)
        icon(cr, icon_code(weather.code, weather.is_day == 1), ICON_X, ICON_Y, ICON_SIZE)
        if os.time() - weather.fetched > 10800 then
            txt(cr, 'Updating…', 209, 160, 12, MUTED)
        end
    end
    cairo_destroy(cr)
    Surface.release(surface, owned)
end
