# Visual refinements (v2)

Based on screenshots of the original weather and Sun/Moon widgets.

## What changed

- The weather condition icon is shifted **23 pixels left and 20 pixels up** at scale 1.0. You can now customize it using `weather_icon_x`, `weather_icon_y`, and `weather_icon_size` under `[appearance]` in `settings.ini`.
- Sunrise and sunset *times* appear outside the ring, on either side of the horizon. The horizon is interrupted behind the center phase icon, so its outline never competes with the line.
- A new section below the ring shows **DAYLIGHT** (today's sunrise to sunset), **TONIGHT** (today's sunset to tomorrow's sunrise), plus a gold/blue bar showing their relative lengths. The horizon itself remains horizontal.
- The moon-phase images use empty, transparent interiors and white rounded outlines. Crescents come from your uploaded WeatherDesk crescent (31.png); the other phases were drawn in a matching stroke style.
- Both new Conky configs set a font explicitly to address the fallback `6x10` warning (whether this suppresses the warning can depend on the installed Conky build).
- The drawing window for Sun/Moon is taller, making room for the duration readouts.
- The previous Open-Meteo local-date/timezone fix remains included.

## Update ONLY the two new widgets you are already testing

Extract the **refinement patch ZIP** directly into the folder containing your existing `Weather.lua`, `Sun_Moon.lua`, and `settings.ini`. Your existing `settings.ini` is **not included** in the patch; your location, scales, and positions will be preserved.

From within that folder:

```bash
python3 upgrade_settings.py
python3 configure.py --check
python3 restart_new.py
```

`restart_new.py` stops only the Conky processes running **this folder's** `conky_weather.conf` and `conky_sun_moon.conf` and launches the two again. It does not stop your prayer or date widgets. For manual checking: `python3 restart_new.py --list` or `python3 restart_new.py --stop-only`.

If you prefer to test from a fresh directory, extract the **full v2 package**, verify or copy your original `settings.ini`, and run:

```bash
python3 weather_fetch.py --force
bash start.sh --new-only
```

## Customize icon location

Edit `settings.ini` (in the folder from which you start Conky):

```ini
[appearance]
weather_icon_x = 174
weather_icon_y = -13
weather_icon_size = 137
```

Smaller X moves the icon left; smaller Y moves it up. These coordinates are measured within the weather widget **before** applying `weather_scale`. Restart the two new widgets after changes.

## Data interpretation

The moving sun is a daytime-progress indicator. The moving blue dot is *nighttime progress*, not the Moon's position in the sky. The static center icon is the approximate Moon illumination phase, based on a lightweight solar/lunar longitude calculation. DAYLIGHT and TONIGHT describe complete **time intervals**, not time remaining. The bottom bar is proportional to those intervals.

The display cannot be rendered/tested on your exact KDE/Wayland system here; use the screenshots from your own desktop to validate spacing and tune the icon X/Y if needed.
