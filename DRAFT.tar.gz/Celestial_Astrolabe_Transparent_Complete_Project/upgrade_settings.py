#!/usr/bin/env python3
"""Append only the missing weather/sun-moon options to an existing settings.ini."""
from pathlib import Path
import configparser
import re

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'settings.ini'
OPTIONS = {
    'appearance': {
        'weather_scale': '1.0',
        'sun_moon_scale': '1.0',
        'weather_icon_x': '174',
        'weather_icon_y': '-13',
        'weather_icon_size': '137',
    },
    'behavior': {
        'weather_refresh_minutes': '20',
    },
    'placement': {
        'weather_x': '40',
        'weather_y': '40',
        'sun_moon_x': '420',
        'sun_moon_y': '40',
    },
}


def upgrade(path=CONFIG):
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=('#', ';'))
    cp.read(path, encoding='utf-8')
    lines = path.read_text(encoding='utf-8').splitlines(keepends=True)
    current = None
    result = []
    changed = []

    def insert_missing(section):
        if section in OPTIONS:
            for key, default in OPTIONS[section].items():
                if not cp.has_option(section, key):
                    result.append(f'{key} = {default}\n')
                    changed.append(f'{section}.{key}')

    for line in lines:
        match = re.match(r'^\s*\[([\w_]+)\]\s*$', line.strip())
        if match:
            insert_missing(current)
            current = match.group(1)
        result.append(line)
    insert_missing(current)
    for section in OPTIONS:
        if not cp.has_section(section):
            result.append(f'\n[{section}]\n')
            for key, default in OPTIONS[section].items():
                result.append(f'{key} = {default}\n')
                changed.append(f'{section}.{key}')
    if changed:
        path.write_text(''.join(result), encoding='utf-8')
    return changed


if __name__ == '__main__':
    print('Added settings: ' + (', '.join(upgrade()) or '(none; already current)'))
