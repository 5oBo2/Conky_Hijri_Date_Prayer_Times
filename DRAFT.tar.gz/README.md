# Prayer Times + Hijri Clock for Conky

Two transparent desktop widgets for Linux (especially KDE Plasma), with prayer-time countdowns, a Gregorian/Hijri clock, optional Athan audio, and hover-to-reveal elapsed prayer time. Location, scale, placement, and behavior are all configured in **one editable `settings.ini` file**. The bundled defaults reproduce the original Cairo, two-monitor layout (you can change them individually).

This archive contains the complete application scripts, configuration wizard, monitor-aware layout helper, launch script, optional KDE/XDG Autostart installer, and diagnostics. **Supply your own `athan.wav` recording** in the installation folder. It does not include Conky, Python, or system fonts, which must be installed through your Linux distribution.

## 1. Requirements

- Linux with graphical desktop; intended for KDE Plasma under X11 or Wayland.
- Conky with **Lua Cairo** support for drawing. **Mouse events** must be listed in `conky --version` for hover interaction. Conky 1.22.2-pre with those features is suitable for testing.
- Python **3.9+** (standard library only). Internet access to the Aladhan prayer-time API (HTTPS).
- Optional: `paplay` command for Athan audio playback (provided by PulseAudio/PipeWire-compatible tools).
- Optional: `kscreen-doctor` (KDE Plasma) for automatic detection of monitor size and position.
- Install **ITC Avant Garde Pro XLt** to reproduce the bundled appearance. If unavailable, change `font` in `settings.ini` to an installed font such as `DejaVu Sans`. Fonts are not included.

On Fedora KDE, check your distro repository for the `conky` and `python3` packages; install the corresponding `paplay` and KScreen utilities if needed. Verify with:

```bash
conky --version
python3 --version
kscreen-doctor -o
command -v paplay
```

No separate Lua JSON parser, pip modules, or external download scripts are needed. Conky itself and its compiled drawing/mouse features cannot be supplied as portable binaries in this ZIP.

## 2. Installation on a new machine

1. Extract this ZIP to any folder (for example `~/Downloads/Conky_Prayer_Complete`).
2. Open a terminal **inside the extracted folder** and run:

   ```bash
   bash install.sh
   ```

   This installs the included files into **`~/.config/conky/`**, offers a choice to configure prayer, date, shared settings or both, and creates **one** login launcher at `~/.config/autostart/conky-prayer-clock.desktop`. It backs up an existing Conky directory if one is already there. If running the installer without a terminal, configure afterwards using step 3.

3. Set your city, sizes and monitor placement when prompted, or later with:

   ```bash
   python3 ~/.config/conky/configure.py
   python3 ~/.config/conky/configure.py --widget prayer
   python3 ~/.config/conky/configure.py --widget date
   python3 ~/.config/conky/configure.py --layout --widget prayer
   ```

4. Place your Athan WAV file beside `install.sh` **before** installing (the installer copies it), or copy it afterwards to:

   ```text
   ~/.config/conky/athan.wav
   ```

5. Check the setup and start both widgets:

   ```bash
   python3 ~/.config/conky/doctor.py
   python3 ~/.config/conky/doctor.py --fetch
   bash ~/.config/conky/start.sh
   ```

   The first prayer data download may take a few seconds and requires Internet. **Both widgets will also start automatically at your next login.** Do not create additional KDE Autostart entries for each widget on top of the one installed by this script, or you will run duplicate instances.

To install without creating Autostart, use `bash install.sh --no-autostart`; to install without prompting for configuration, use `bash install.sh --no-configure`. Both options may be combined. An existing `settings.ini` is **kept by default** during reinstallation. To replace it with the packaged Cairo defaults deliberately, run `bash install.sh --reset-settings` (the existing directory is backed up). If you have two existing KDE Autostart entries for `conky_date.conf` and `conky_prayer_times.conf`, disable them when using the single generated launcher; or run with `--no-autostart` and retain those two entries.

## 3. Single-file configuration

All normal settings live in `~/.config/conky/settings.ini`. The defaults below match your Cairo/two-display setup; **on a different monitor arrangement, run the layout assistant** before using the widgets:

```ini
[location]
mode = coordinates
city = Cairo
country = Egypt
state =
latitude = 30.0444
longitude = 31.23575
method = auto
school = 0
midnight_mode = 1

[appearance]
prayer_scale = 1.0
date_scale = 1.0
font = ITC Avant Garde Pro XLt

[behavior]
elapsed_minutes = 60
hover_area = fajr_sunrise
hover_debug_outline = no
hover_failsafe_seconds = 5
hijri_offset_days = 0
athan_enabled = yes

[placement]
prayer_x = 1930
prayer_y = 800
date_x = 3200
date_y = 75
```

Use `mode = city` to specify a city and country; `state` helps disambiguate names. For precise positioning set `mode = coordinates` and adjust latitude/longitude. `method = auto` uses Aladhan's default calculation method for the location, `school = 1` selects Hanafi Asr, and `midnight_mode = 1` selects the configured midnight convention. Compare the times with your local mosque if accuracy is critical.

**Timezone:** Countdown calculations interpret the API's local prayer clock times in the computer's own timezone. Your machine's timezone must match the selected prayer location. For a different timezone, change the machine timezone or use a location within the same timezone. Check with `timedatectl`.

**Widget size:** `prayer_scale` and `date_scale` both scale the Cairo text **and** the Conky window's reserved dimensions. Values **0.3 to 3.0** are allowed, where `1.0` is the default, `0.5` is half-sized and `1.5` is 50% larger. At scale 1.0, estimated window rectangles are **1100×255** (prayer times) and **700×290** (clock/date). The actual ink can depend on the font, so visually inspect for clipping.

**Elapsed time:** `elapsed_minutes = 60` displays “Since Asr”, for example, automatically for one hour after the prayer. Once the hour passes, hovering over the prayer widget reveals it again. `elapsed_minutes = 0` means hover-only. `hijri_offset_days` adds or subtracts whole Hijri days.

**Athan audio:** Set `athan_enabled = yes` and provide `athan.wav` beside the scripts. Audio uses `paplay` and plays when a prayer time is crossed while Conky is already running. It will not replay at startup or after a long system suspend. File name **must** be `athan.wav` (lowercase). Sunrise and midnight are displayed but do not trigger Athan.

**Font:** The bundled configuration requests `ITC Avant Garde Pro XLt`. Install it if licensed/available on your machine. Otherwise change `font = DejaVu Sans` (or another installed family). Verify with `fc-match 'ITC Avant Garde Pro XLt'`. The ZIP does not contain font files.

### Configure only one widget

Run `python3 ~/.config/conky/configure.py` and select **1 Prayer**, **2 Date/Hijri**, **3 Shared**, or **4 Both**. Or use explicit commands:

```bash
# Prayer scale, elapsed display, hover zone, audio, position
python3 ~/.config/conky/configure.py --widget prayer
# Date widget size, Hijri offset, position
python3 ~/.config/conky/configure.py --widget date
# Location, prayer calculation method and common font (affects both widgets)
python3 ~/.config/conky/configure.py --widget shared
# Everything (for a first-time setup)
python3 ~/.config/conky/configure.py --widget both
```

Changes go **directly into `settings.ini`**, retaining its descriptive comments. You can edit the same file manually whenever you like; the wizard reads those values next time. In a one-widget session, the other widget's scale and X/Y remain untouched. **Shared** location and font values intentionally apply to both widgets. When asked about placement, choose `keep`, `auto` or `manual`.

Restart the widgets after editing settings. Most scripts read values only when Conky starts.

## 4. Automatic multi-monitor positioning / layout presets

To see your display boundaries and estimated widget rectangles:

```bash
python3 ~/.config/conky/configure.py --screens
python3 ~/.config/conky/configure.py --check-layout
# Check just one widget:
python3 ~/.config/conky/configure.py --check-layout --widget prayer
python3 ~/.config/conky/configure.py --check-layout --widget date
```

To place each widget **without guessing X, Y, max width, or height**:

```bash
python3 ~/.config/conky/configure.py --layout
# Or configure the layout of just one widget:
python3 ~/.config/conky/configure.py --layout --widget prayer
python3 ~/.config/conky/configure.py --layout --widget date
```

The assistant first reads the **live** monitor geometry from `kscreen-doctor -o` (falling back to `-j`). If that fails, it offers a **manual monitor-geometry entry** instead of quitting. Look at **System Settings → Display & Monitor** or use `kscreen-doctor -o` for positions and **logical** dimensions. To save your geometry independently of the widget layout and reuse it in future checks:

```bash
python3 ~/.config/conky/configure.py --manual-screens
python3 ~/.config/conky/configure.py --check-layout
```

Manual monitor geometry is saved as `monitor_geometry.json` and reused **only when live detection fails**. If you later rearrange or resize screens, run `--manual-screens` again; the saved geometry is not automatically refreshed. `--check-layout` always shows estimated widget rectangles even without any monitor information, but it can only confirm on/off-screen fit if geometry is available. To diagnose why auto-detection is failing, run `kscreen-doctor -o` from a terminal inside the Plasma session. KDE versions differ in how that command formats its output.

Choose each monitor; scale or a maximum share of its width/height; anchor position (top-left, bottom-center, etc.); and margins. It calculates X/Y for the Conky config. Conky has `minimum_width`, `minimum_height`, and `maximum_width` but not a corresponding `maximum_height`; this project instead derives both dimensions from the scale.

For large full-screen and compact layouts:

```bash
# Set your larger layout in the wizard, then save:
python3 ~/.config/conky/configure.py --save-layout full

# Set a smaller layout in the wizard, then save:
python3 ~/.config/conky/configure.py --save-layout compact

# Switch at any time:
python3 ~/.config/conky/configure.py --use-layout full
python3 ~/.config/conky/configure.py --use-layout compact
python3 ~/.config/conky/configure.py --list-layouts
```

Named presets save only X/Y and scales; your location and other behavior stay unchanged. Add `--widget prayer` or `--widget date` to `--save-layout` or `--use-layout` to save/apply only that widget without affecting the other. For example:

```bash
python3 ~/.config/conky/configure.py --save-layout compact --widget prayer
python3 ~/.config/conky/configure.py --use-layout compact --widget prayer
```

A partially saved preset only applies values that exist in the preset; an existing preset retains the other widget's saved values when you save just one. Restart both widgets after changing presets. On Wayland, KWin's window placement rules can differ from the screen geometry, so these are **estimates** rather than guaranteed physical bounds.

## 5. Hover on Plasma Wayland

If your Conky build has mouse-event support, the prayer widget responds to `mouse_enter`, `mouse_move` and `mouse_leave`. `hover_area = fajr_sunrise` restricts activation to a small region covering the Fajr/Sunrise headings (a hover hotspot above the first two columns). `hover_area = content` covers the prayer labels and countdowns; `hover_area = window` uses the full transparent window rectangle. Set `hover_debug_outline = yes` temporarily to draw a thin red border around the small hotspot; set it back to `no` after checking its position.

Fast pointer movements or crossing displays can sometimes cause a missed `mouse_leave` on Wayland/XWayland. To avoid a stuck elapsed-time display, `hover_failsafe_seconds = 5` automatically clears the hover state if there have been no mouse events for five seconds. Change this number as desired; `0` disables the failsafe, but risks indefinitely stuck hover. **Trade-off:** a stationary cursor over the text also times out after this period. Moving again reveals elapsed time. There is no reliable generic global-cursor-position API available to an ordinary Conky Lua script under Wayland.

During the configured first hour (or custom elapsed period) the elapsed text remains visible even when not hovered; that behavior is intentional.

## 6. KDE Autostart / manually starting

The installer creates a standard XDG Autostart file, one entry for both widgets. It starts them after a brief login delay. You can remove it from **System Settings → Autostart**, or delete `~/.config/autostart/conky-prayer-clock.desktop`.

If you prefer your own two separate KDE Autostart entries instead, the commands are:

```bash
conky -d -c ~/.config/conky/conky_date.conf
conky -d -c ~/.config/conky/conky_prayer_times.conf
```

For KDE's **Program** field use `conky`, with **Arguments** set to `-c /home/YOUR_USERNAME/.config/conky/conky_date.conf` (and the matching prayer config for the other). The `-d` flag is optional for each entry. Do **not** run the installer-generated Autostart launcher at the same time.

If the two windows are already running, quit them before restarting to avoid duplicated widgets. This command terminates **all** Conky instances:

```bash
pkill -x conky
bash ~/.config/conky/start.sh
```

## 7. Troubleshooting

- **Prayer text reads “Fetching…”:** Check Internet, location and timezone. Run `python3 ~/.config/conky/doctor.py --fetch`, then inspect `~/.cache/conky-prayer-times/fetch.log` (or `$XDG_CACHE_HOME/conky-prayer-times/fetch.log`). The cache files are automatically shared between widgets and invalidated when you change the location settings.
- **Nothing appears:** Run `conky -c ~/.config/conky/conky_prayer_times.conf` in a terminal, not `-d`, to see any errors; check `conky --version` for Lua Cairo. Try the date config in the same way. No actual GUI rendering can be pre-tested on a different computer.
- **Widget appears above applications:** Both configs use `own_window_type = 'normal'` and the `below` hint, not `panel`. KDE's compositor may still handle XWayland and native Wayland surfaces differently; check your Conky output backend and Plasma window rules.
- **Hover is unreliable:** Verify `Mouse events` under `conky --version`. The configured missed-leave failsafe is not an exact cursor tracker. Try `hover_failsafe_seconds = 2` for faster recovery, or a larger value for easier reading when stationary.
- **The widget is off-screen:** Run the layout wizard or manually edit `[placement]`. If monitor auto-detection fails, use `--manual-screens` to enter the layout once and run `--check-layout` again. In a multi-monitor desktop, the second screen's X origin may already exceed the first screen's width.
- **No audio:** Confirm `~/.config/conky/athan.wav` exists and that `paplay ~/.config/conky/athan.wav` works. Conky intentionally does not replay audio for prayers already past when it starts.
- **Hijri date differs by one day:** Change `hijri_offset_days` to `1` or `-1`, and restart. The clock advances Hijri day at Maghrib using the selected location's prayer data.

The widgets use the [Aladhan API](https://aladhan.com/prayer-times-api) for dates and prayer schedules. No API key is required for the public endpoints used here; network access is needed to populate each day's cache.
