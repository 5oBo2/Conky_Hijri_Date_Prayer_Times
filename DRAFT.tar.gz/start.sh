#!/usr/bin/env bash
# Launch both Conky windows from this folder. Can also be used by KDE Autostart.
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ "${1:-}" == '--delay' ]]; then
  seconds="${2:-5}"
  [[ "$seconds" =~ ^[0-9]+$ ]] || { echo 'Delay must be a nonnegative integer.' >&2; exit 2; }
  sleep "$seconds"
elif [[ $# -gt 0 ]]; then
  echo 'Usage: start.sh [--delay SECONDS]' >&2
  exit 2
fi
if ! command -v conky >/dev/null 2>&1; then
  echo 'Conky is missing. Install Conky with Lua/Cairo support.' >&2
  exit 1
fi
conky -d -c "$DIR/conky_date.conf"
conky -d -c "$DIR/conky_prayer_times.conf"
